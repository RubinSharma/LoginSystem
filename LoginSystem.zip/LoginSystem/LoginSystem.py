import numpy as np
import csv
import os
import pandas as pd


os.chdir('D:\PythonProjects\LoginSystem')

#asking user for the username and password

def add_new_user():
    print('Welcome to this login system \n')
    username = input('Enter your your name: ')
    password = input('Enter your password: ')

#creating list for storing username and password
    list_username = []
    list_password = []

#reading the csv file as dictionary
    def reading_csv_file():    
        with open("credentials.csv", 'r') as csv_file:
            csv_dict_reader = csv.DictReader(csv_file)    

            for row in csv_dict_reader:
                list_username.append(row['username'])
                list_password.append(row['password'])
    
        return csv_dict_reader

#writing to the csv file
    def writing_to_csv_file():
        with open('credentials.csv', 'a', newline = '') as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow([username, password])

    reading_csv_file()

    def list_of_credentials():
        credential_df = pd.read_csv('credentials.csv')
        print(credential_df)

    if username in list_username:
        print('\nThe user already exist\nHere is a list of other credentials\n')
        list_of_credentials()
    else:
        writing_to_csv_file() #writing to the csv file only if the user doesnot exist
        print('\nUser added successfully.\nHere is a list of other credentials\n')
        list_of_credentials()


#the program will loop untill the user enters either   1 or 2
print('Now lets go to the login system')
valid_choice = [1,2]
user_choice = 999
while user_choice != valid_choice:
    user_choice = int(input('Do you want to add new user(1) or check your login(2): '))
    if user_choice == valid_choice[0]:
        add_new_user()
        break               #this break stops the program from running again and again so does other break in line 85-88-91-94
    
    elif user_choice == valid_choice[1]:

        credential_df = pd.read_csv('credentials.csv') #creating the pandas list of username and password
        user_name_pandas_list = credential_df['username']
        pass_word_pandas_list = credential_df['password']

        new_username_list = []                          #converting the pandas list(coulumn) to python list
        new_password_list = []

        for i in user_name_pandas_list:
            new_username_list.append(i)

        for j in pass_word_pandas_list:
            new_password_list.append(j)

        username = input('Enter the username: ')
        password = input('Enter the password: ')

        if username in new_username_list:
            password_index = new_username_list.index(username)

            if new_password_list[password_index] == password:
                print('Password match successfully.\nYou are allowed complete access.')
                break
            else:
                print('Password is incorrect.\nPlease try again later')
                break
        else:
            print('The username you are looking for doesnot exist')
            break
    else:
        print('You have entered invalid value\nPlease try again.')
        break
